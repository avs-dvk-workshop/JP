---
title: '2. Get an Amazon Dev Account'


layout: nil
---

{:.steps}
### Register for an Amazon Developer Account

Unless you already have one, go ahead and create a free developer account at [developer.amazon.com](https://developer.amazon.com/login.html). You should review the **AVS Terms and Agreements** [here](https://developer.amazon.com/public/solutions/alexa/alexa-voice-service/support/terms-and-agreements).

{:.verify}
### Checkpoint 2
1. Login and navigate to [https://developer.amazon.com/edw/home.html](https://developer.amazon.com/edw/home.html)
